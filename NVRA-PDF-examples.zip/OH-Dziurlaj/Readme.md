** Example of use of the NIST OVR Draft CDF **
These files are for a standalone, working example of the NIST VRI CDF as an XML based PDF. The PDF 
password is the capital of Ohio, in ALL CAPS). You'll need Acrobat Standard or Professional to Import or 
Export the data.
 Steps (based on Acrobat Pro XI):
1. Click on Tools
2. Click on Forms -> More Form Options
3. Select Import Data (ALL DATA IS FICTITIOUS)
4. You'll select one of the XML files attached. The files simulate various registration scenarios 
(registration / update / in state / out of state / out of country). The PDF will run the XSL and bind to the 
fields of the form.
Note that the CDF version implemented in this example is several versions behind the current version, 
however the differences will be relatively minor.
